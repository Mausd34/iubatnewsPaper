from django.apps import AppConfig


class ArticlesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.articles"
    label = "articles"

    def ready(self):
        from . import signals  # noqa: F401
